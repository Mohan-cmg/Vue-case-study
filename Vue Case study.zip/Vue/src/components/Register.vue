<template>
  <span>
    <div class="hello">     
      <form >
        <label>user name:</label>
        <input type="text" v-model.lazy="blog.username"  required>
        <br>
        <label>Password:</label>
        <input type="text"  v-model.lazy="blog.password"  required>
        <br>
        <label >Confirm Password:</label>
        <input type="text"  v-model.lazy="blog.password"  required>
        <br>
        <label >Email:</label>
        <input type="text"  v-model.lazy="blog.email"  required>
         <button v-on:click.prevent="addBlog()">Register</button>
         &nbsp; &nbsp;          
      </form>
    </div>    
  </span>

</template>

<script>
export default {
  name: 'Register',
  data: function(){
      return {         
          blog:{
             "username": "",
             "password": "",
             "email": ""
          }
      }
 },
 methods:{
   addBlog: function(){
     this.$http.post('http://localhost:3000/userdetails', this.blog)
              .then(res=>{
                console.log(res)
                //this.$router.push({path:'/show'})
              }, err=>{
                console.log(err)
              })
   }
 }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
