import ShowBlog from "../components/ShowBlog.vue";
import HelloWorld from "../components/HelloWorld.vue";
import Blog from "../components/Blog.vue";
import Register from "../components/Register.vue";

export default [
    {
        path:'/',
        component:Register
    },
    {
        path:'/show',
        component:ShowBlog
    },   
    {
        path:'/edit/:myid',
        component:Blog
    }
]